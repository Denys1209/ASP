﻿using Microsoft.AspNetCore.Mvc;

namespace NovelCatalog.WebApi.Controllers;

[Route("api/[controller]")]
public abstract class Controller : ControllerBase
{

}
