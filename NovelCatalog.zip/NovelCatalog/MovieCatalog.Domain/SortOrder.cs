﻿namespace NovelCatalog.Domain;

public enum SortOrder
{
	Asc,
	Desc
}
